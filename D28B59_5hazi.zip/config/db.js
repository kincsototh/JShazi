var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/d28b59', 
    {useNewUrlParser : true});

module.exports = mongoose;