var Schema = require('mongoose').Schema;
var db = require('../config/db');

var Teacher = db.model('Teacher', {
  name: String,
  field: String,
  email: String,
  phone_num: String,
});

module.exports = Teacher;
