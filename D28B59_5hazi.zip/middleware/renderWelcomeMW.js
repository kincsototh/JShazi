module.exports = (req, res) => {
    res.render('welcome', { 
        title: "ZENEISKOLAI NYILVÁNTARTÁS"
    });
};
